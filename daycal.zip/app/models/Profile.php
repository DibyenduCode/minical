<?php

namespace App\Models;

use App\Core\Model;

class Profile extends Model {
    protected string $table = 'profiles';

    public function findByUserId(int $userId): ?array {
        $stmt = $this->db->prepare("SELECT * FROM `profiles` WHERE `user_id` = :user_id LIMIT 1");
        $stmt->execute(['user_id' => $userId]);
        $res = $stmt->fetch();
        return $res ?: null;
    }

    public function findByCustomDomain(string $domain): ?array {
        $domain = strtolower(trim($domain));
        if (empty($domain)) return null;

        $stmt = $this->db->prepare("
            SELECT p.*, u.username, u.name, u.email, u.status 
            FROM `profiles` p 
            JOIN `users` u ON u.id = p.user_id 
            WHERE LOWER(p.`custom_domain`) = :domain AND u.`status` = 'active' 
            LIMIT 1
        ");
        $stmt->execute(['domain' => $domain]);
        $res = $stmt->fetch();
        return $res ?: null;
    }

    public function updateByUserId(int $userId, array $data): bool {
        $customDomain = !empty($data['custom_domain']) ? strtolower(trim($data['custom_domain'])) : null;
        if ($customDomain) {
            $customDomain = preg_replace('#^https?://#', '', $customDomain);
            $customDomain = rtrim($customDomain, '/');
        }

        $stmt = $this->db->prepare("
            UPDATE `profiles` 
            SET `phone` = :phone, `timezone` = :timezone, `company_name` = :company_name, `custom_domain` = :custom_domain, `bio` = :bio, `avatar` = :avatar, `upi_id` = :upi_id, `qr_code` = :qr_code
            WHERE `user_id` = :user_id
        ");
        return $stmt->execute([
            'phone'         => $data['phone'] ?? null,
            'timezone'      => $data['timezone'] ?? 'UTC',
            'company_name'  => $data['company_name'] ?? null,
            'custom_domain' => $customDomain,
            'bio'           => $data['bio'] ?? null,
            'avatar'        => $data['avatar'] ?? null,
            'upi_id'        => $data['upi_id'] ?? null,
            'qr_code'       => $data['qr_code'] ?? null,
            'user_id'       => $userId
        ]);
    }
}
