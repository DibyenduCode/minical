<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in - DayCal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
</head>
<body class="bg-[#fafafa] text-slate-900 min-h-screen flex items-center justify-center p-4">
    <div class="w-full max-w-md bg-white rounded-3xl border border-slate-200/90 shadow-xl shadow-slate-200/50 p-8 space-y-6">
        <div class="text-center space-y-2">
            <div class="flex justify-center mb-2">
                <img src="<?= APP_URL ?>/public/logo.jpg" alt="DayCal Logo" class="w-12 h-12 rounded-2xl shadow-sm object-cover">
            </div>
            <h1 class="text-2xl font-extrabold text-slate-950 tracking-tight">Welcome back to DayCal</h1>
            <p class="text-slate-500 text-xs font-medium">Sign in to manage your appointments and schedule</p>
        </div>

        <?php if (!empty($error)): ?>
            <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl text-xs font-semibold flex items-center gap-2">
                <svg class="w-4 h-4 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 px-4 py-3 rounded-2xl text-xs font-semibold flex items-center gap-2">
                <svg class="w-4 h-4 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                <span><?= htmlspecialchars($success) ?></span>
            </div>
        <?php endif; ?>

        <form action="<?= APP_URL ?>/login" method="POST" class="space-y-4">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

            <div>
                <label for="email" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Email address</label>
                <input type="email" id="email" name="email" required placeholder="admin@daycal.in"
                    class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-medium text-sm focus:outline-none focus:ring-2 focus:ring-black focus:bg-white transition-all">
            </div>

            <div>
                <div class="flex items-center justify-between mb-1.5">
                    <label for="password" class="block text-xs font-bold text-slate-700 uppercase tracking-wider">Password</label>
                    <a href="<?= APP_URL ?>/forgot-password" class="text-xs font-bold text-slate-600 hover:text-black hover:underline">Forgot password?</a>
                </div>
                <input type="password" id="password" name="password" required placeholder="••••••••"
                    class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-medium text-sm focus:outline-none focus:ring-2 focus:ring-black focus:bg-white transition-all">
            </div>

            <button type="submit"
                class="w-full py-3.5 px-4 bg-black hover:bg-slate-800 text-white font-bold text-sm rounded-xl shadow-md transition-all transform active:scale-[0.98] mt-2">
                Sign in
            </button>
        </form>

        <div class="pt-4 border-t border-slate-100 text-center">
            <p class="text-slate-500 text-xs font-medium">Don't have an account? 
                <a href="<?= APP_URL ?>/register" class="text-black font-bold hover:underline">Create one for free</a>
            </p>
        </div>
    </div>
</body>
</html>
