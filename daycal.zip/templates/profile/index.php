<?php
$title = "Profile Settings";
$activeTab = "profile";
require_once TEMPLATES_DIR . '/layout/header.php';
?>

<div class="max-w-4xl mx-auto space-y-8">
    <?php if (!empty($success)): ?>
        <div class="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-3 rounded-2xl text-xs font-semibold flex items-center gap-2">
            <svg class="w-4 h-4 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
            <span><?= htmlspecialchars($success) ?></span>
        </div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <div class="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-2xl text-xs font-semibold flex items-center gap-2">
            <svg class="w-4 h-4 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span><?= htmlspecialchars($error) ?></span>
        </div>
    <?php endif; ?>

    <!-- Profile & Branding Settings Section -->
    <div class="bg-white border border-slate-200/90 rounded-3xl p-8 space-y-6 shadow-sm">
        <div>
            <h1 class="text-2xl font-extrabold text-slate-950 tracking-tight">Profile & Branding Settings</h1>
            <p class="text-slate-500 text-xs font-medium mt-1">Manage your account details, company brand, logo, and custom domain.</p>
        </div>

        <form action="<?= APP_URL ?>/profile" method="POST" enctype="multipart/form-data" class="space-y-6">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

            <!-- Brand Logo Upload Card -->
            <div class="p-6 bg-slate-50 border border-slate-200/80 rounded-2xl flex flex-col sm:flex-row items-center gap-6">
                <div class="relative w-20 h-20 bg-black text-white rounded-3xl flex items-center justify-center font-bold text-2xl overflow-hidden border border-slate-200 shadow-sm">
                    <?php if (!empty($profile['avatar'])): ?>
                        <img src="<?= APP_URL ?>/<?= htmlspecialchars($profile['avatar']) ?>" class="w-full h-full object-cover">
                    <?php else: ?>
                        <?= strtoupper(substr($user['name'], 0, 2)) ?>
                    <?php endif; ?>
                </div>

                <div class="space-y-2 text-center sm:text-left flex-1">
                    <h3 class="font-bold text-slate-900 text-sm">Brand Logo / Company Avatar</h3>
                    <p class="text-slate-500 text-xs mt-0.5">Upload a square logo (JPG, PNG, WEBP) to brand your public booking link.</p>
                    <input type="file" name="avatar_file" accept="image/*" class="text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-black file:text-white file:cursor-pointer hover:file:bg-slate-800">
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Full Name</label>
                    <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required
                           class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-black">
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 font-sans">Username (Booking Link)</label>
                    <div class="relative flex items-center">
                        <span class="absolute left-4 text-xs font-bold text-slate-400 select-none">/u/</span>
                        <input type="text" id="username_input" name="username" value="<?= htmlspecialchars($user['username']) ?>" required
                               class="w-full pl-8 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-black font-semibold">
                    </div>
                    <span id="username_status" class="block text-[10px] font-bold mt-1.5 hidden"></span>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 font-sans">Email Address</label>
                    <input type="email" value="<?= htmlspecialchars($user['email']) ?>" disabled
                           class="w-full px-4 py-3 bg-slate-100 border border-slate-200 rounded-xl text-slate-400 text-sm cursor-not-allowed">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Company / Brand Name</label>
                    <input type="text" name="company_name" value="<?= htmlspecialchars($profile['company_name'] ?? '') ?>" placeholder="e.g. DK Tech"
                           class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-black">
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Phone Number</label>
                    <input type="text" name="phone" value="<?= htmlspecialchars($profile['phone'] ?? '') ?>" placeholder="+1 (555) 000-0000"
                           class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-black">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Timezone</label>
                    <select name="timezone" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-black">
                        <?php
                        $tzs = ['UTC', 'America/New_York', 'America/Los_Angeles', 'Europe/London', 'Asia/Kolkata', 'Asia/Dhaka', 'Asia/Tokyo'];
                        $currentTz = $profile['timezone'] ?? 'UTC';
                        foreach ($tzs as $t) {
                            $selected = ($t === $currentTz) ? 'selected' : '';
                            echo "<option value='{$t}' {$selected}>{$t}</option>";
                        }
                        ?>
                    </select>
                </div>

                <div>
                    <!-- Custom Branded Domain Section (Cal.com style) -->
                    <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Custom Domain / Subdomain
                        <?php if (empty($planDetails['allow_custom_domain'])): ?>
                            <span class="ml-1 text-[10px] text-indigo-600 bg-indigo-50 border border-indigo-200/60 px-1.5 py-0.5 rounded font-extrabold uppercase">Requires Upgrade</span>
                        <?php endif; ?>
                    </label>
                    <input type="text" name="custom_domain" value="<?= htmlspecialchars($profile['custom_domain'] ?? '') ?>" placeholder="booking.dibyendu.in"
                           <?= empty($planDetails['allow_custom_domain']) ? 'disabled class="w-full px-4 py-3 bg-slate-100 border border-slate-200 rounded-xl text-slate-400 text-sm font-mono cursor-not-allowed"' : 'class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-black"' ?>>
                </div>
            </div>

            <div class="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs text-slate-600">
                <p class="font-bold text-slate-900">DNS Setup Instructions for your domain registrar:</p>
                <ul class="list-disc list-inside space-y-1 text-slate-600 font-mono text-[11px]">
                    <li>Record Type: <strong class="text-black">CNAME</strong></li>
                    <li>Name / Host: <strong class="text-black">booking</strong> (or your subdomain name)</li>
                    <li>Target / Value: <strong class="text-black">xyz.com</strong> (or your main platform domain)</li>
                </ul>
            </div>

            <div>
                <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Bio / Description</label>
                <textarea name="bio" rows="3" placeholder="Tell clients about yourself..."
                          class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-black"><?= htmlspecialchars($profile['bio'] ?? '') ?></textarea>
            </div>

            <!-- Payment Configuration Section -->
            <div class="border-t border-slate-100 pt-6 space-y-4">
                <h3 class="text-sm font-extrabold text-slate-900 uppercase tracking-wider">Manual Payment Credentials</h3>
                <p class="text-slate-500 text-xs mt-0.5">Define your UPI details so clients can scan and pay manually.</p>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">UPI ID (for payments)</label>
                        <input type="text" name="upi_id" value="<?= htmlspecialchars($profile['upi_id'] ?? '') ?>" placeholder="name@upi"
                               class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-black font-semibold">
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Payment QR Code</label>
                        <div class="flex items-center gap-4">
                            <?php if (!empty($profile['qr_code'])): ?>
                                <div class="w-12 h-12 border border-slate-200 rounded-lg overflow-hidden flex-shrink-0">
                                    <img src="<?= APP_URL ?>/<?= htmlspecialchars($profile['qr_code']) ?>" class="w-full h-full object-cover">
                                </div>
                            <?php endif; ?>
                            <input type="file" name="qr_code_file" accept="image/*" class="text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-black file:text-white file:cursor-pointer hover:file:bg-slate-800">
                        </div>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 border-t border-slate-100 pt-6">
                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Subscription Plan</label>
                    <div class="flex items-center gap-3 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                        <span class="text-sm font-bold text-slate-900">
                            <?= isset($planDetails['name']) ? htmlspecialchars($planDetails['name']) : 'Free Plan' ?>
                        </span>
                        <span class="text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-slate-200 text-slate-700 border border-slate-300/40">
                            Active
                        </span>
                    </div>
                    <span class="block text-[10px] text-slate-400 font-semibold mt-1">Managed by Administrator. Please contact support to upgrade or modify your subscription.</span>
                </div>
            </div>

            <div class="pt-2 flex justify-end">
                <button type="submit" class="px-6 py-3 bg-black hover:bg-slate-800 text-white font-semibold text-sm rounded-xl shadow-md transition-all">
                    Save Profile Settings
                </button>
            </div>
        </form>
    </div>

    <!-- Change Password Section -->
    <div class="bg-white border border-slate-200/90 rounded-3xl p-8 space-y-6 shadow-sm mt-8">
        <div>
            <h2 class="text-lg font-bold text-slate-900">Update Password</h2>
            <p class="text-slate-500 text-xs mt-1">Ensure your account is using a long, random password to stay secure.</p>
        </div>

        <form action="<?= APP_URL ?>/profile/change-password" method="POST" class="space-y-4 max-w-md">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

            <div>
                <label for="current_password" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Current Password</label>
                <input type="password" id="current_password" name="current_password" required placeholder="••••••••"
                       class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-black">
            </div>

            <div>
                <label for="new_password" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">New Password</label>
                <input type="password" id="new_password" name="new_password" required placeholder="••••••••"
                       class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-black">
            </div>

            <div>
                <label for="confirm_password" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Confirm New Password</label>
                <input type="password" id="confirm_password" name="confirm_password" required placeholder="••••••••"
                       class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-black">
            </div>

            <div class="pt-2">
                <button type="submit" class="px-6 py-3 bg-black hover:bg-slate-800 text-white font-semibold text-sm rounded-xl shadow-md transition-all">
                    Update Password
                </button>
            </div>
        </form>
    </div>
</div>



<script>
document.addEventListener("DOMContentLoaded", function() {
    const usernameInput = document.getElementById('username_input');
    const usernameStatus = document.getElementById('username_status');
    let timeout = null;

    if (usernameInput) {
        usernameInput.addEventListener('input', function() {
            clearTimeout(timeout);
            const username = usernameInput.value.trim().toLowerCase();
            usernameStatus.classList.add('hidden');

            if (!username) {
                usernameStatus.className = 'block text-[10px] font-bold mt-1.5 text-red-600';
                usernameStatus.innerText = 'Username cannot be empty.';
                usernameStatus.classList.remove('hidden');
                return;
            }

            if (!/^[a-z0-9_-]+$/i.test(username)) {
                usernameStatus.className = 'block text-[10px] font-bold mt-1.5 text-red-600';
                usernameStatus.innerText = 'Letters, numbers, underscores and hyphens only.';
                usernameStatus.classList.remove('hidden');
                return;
            }

            timeout = setTimeout(() => {
                fetch(`<?= APP_URL ?>/api/check-username?username=${username}&exclude_user_id=<?= $user['id'] ?? 0 ?>`)
                    .then(res => res.json())
                    .then(data => {
                        usernameStatus.classList.remove('hidden');
                        if (data.available) {
                            usernameStatus.className = 'block text-[10px] font-bold mt-1.5 text-emerald-600';
                            usernameStatus.innerText = '✓ Username is available';
                        } else {
                            usernameStatus.className = 'block text-[10px] font-bold mt-1.5 text-red-600';
                            usernameStatus.innerText = '✗ Username is already taken';
                        }
                    })
                    .catch(() => {
                        usernameStatus.className = 'block text-[10px] font-bold mt-1.5 text-red-600';
                        usernameStatus.innerText = 'Failed to verify username availability.';
                        usernameStatus.classList.remove('hidden');
                    });
            }, 300);
        });
    }
});
</script>

<?php require_once TEMPLATES_DIR . '/layout/footer.php'; ?>
