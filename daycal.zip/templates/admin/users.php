<?php
$title = "Manage Users - Super Admin";
$adminTab = "users";
require_once TEMPLATES_DIR . '/admin/layout/header.php';
?>

<div class="max-w-7xl mx-auto space-y-8">
    <?php if (!empty($success)): ?>
        <div class="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-3 rounded-2xl text-xs font-semibold flex items-center gap-2">
            <svg class="w-4 h-4 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
            <span><?= htmlspecialchars($success) ?></span>
        </div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <div class="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-2xl text-xs font-semibold flex items-center gap-2">
            <svg class="w-4 h-4 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span><?= htmlspecialchars($error) ?></span>
        </div>
    <?php endif; ?>

    <!-- User Management Section -->
    <div class="bg-white border border-slate-200/90 rounded-3xl p-6 space-y-6 shadow-sm">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-2xl font-extrabold text-slate-950 tracking-tight">Registered Platform Users</h1>
                <p class="text-slate-500 text-xs font-medium mt-1">Manage user accounts, custom white-label domains, and administrative permissions.</p>
            </div>
            <span class="text-xs text-slate-500 font-bold bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200"><?= $totalUsers ?> Accounts Found</span>
        </div>

        <!-- Filters & Search Form -->
        <form method="GET" action="<?= APP_URL ?>/admin/users" class="flex flex-wrap items-center gap-3">
            <input type="text" name="search" value="<?= htmlspecialchars($search ?? '') ?>" placeholder="Search name, email..."
                   class="px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-black">

            <select name="status" onchange="this.form.submit()"
                    class="px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 font-semibold focus:outline-none focus:ring-2 focus:ring-black">
                <option value="">All Statuses</option>
                <option value="active" <?= ($statusFilter === 'active') ? 'selected' : '' ?>>Active</option>
                <option value="disabled" <?= ($statusFilter === 'disabled') ? 'selected' : '' ?>>Disabled</option>
            </select>

            <select name="plan" onchange="this.form.submit()"
                    class="px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 font-semibold focus:outline-none focus:ring-2 focus:ring-black">
                <option value="">All Plans</option>
                <?php foreach ($plans as $p): ?>
                    <option value="<?= htmlspecialchars($p['slug']) ?>" <?= ($planFilter === $p['slug']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($p['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <?php if (!empty($search) || !empty($statusFilter) || !empty($planFilter)): ?>
                <a href="<?= APP_URL ?>/admin/users" class="text-xs font-bold text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 px-3 py-2.5 rounded-xl border border-red-100 transition-colors">
                    Clear Filters
                </a>
            <?php endif; ?>
        </form>

        <div class="overflow-x-auto rounded-2xl border border-slate-200">
            <table class="w-full text-left text-sm text-slate-700">
                <thead class="bg-slate-50 text-xs font-bold text-slate-500 uppercase border-b border-slate-200">
                    <tr>
                        <th class="px-6 py-4">User Details</th>
                        <th class="px-6 py-4">Booking Link</th>
                        <th class="px-6 py-4">Custom Branded Domain</th>
                        <th class="px-6 py-4">Bookings</th>
                        <th class="px-6 py-4">Role</th>
                        <th class="px-6 py-4">Status</th>
                        <th class="px-6 py-4">Subscription Plan</th>
                        <th class="px-6 py-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php foreach ($users as $u): ?>
                        <tr class="hover:bg-slate-50/60 transition-colors">
                            <td class="px-6 py-4">
                                <p class="font-bold text-slate-900 text-sm"><?= htmlspecialchars($u['name']) ?></p>
                                <p class="text-xs text-slate-500"><?= htmlspecialchars($u['email']) ?></p>
                            </td>
                            <td class="px-6 py-4 font-mono text-xs text-slate-600">
                                <a href="<?= APP_URL ?>/u/<?= htmlspecialchars($u['username']) ?>" target="_blank" class="hover:underline text-black font-semibold">
                                    /u/<?= htmlspecialchars($u['username']) ?>
                                </a>
                            </td>
                            <td class="px-6 py-4">
                                <?php if (!empty($u['custom_domain'])): ?>
                                    <a href="http://<?= htmlspecialchars($u['custom_domain']) ?>" target="_blank" class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 hover:underline">
                                        <span>🌐 <?= htmlspecialchars($u['custom_domain']) ?></span>
                                    </a>
                                <?php else: ?>
                                    <span class="text-xs text-slate-400 font-medium italic">None configured</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 text-xs font-bold text-slate-800"><?= $u['total_bookings'] ?> bookings</td>
                            <td class="px-6 py-4 uppercase text-[11px] font-bold text-slate-700"><?= $u['role'] ?></td>
                            <td class="px-6 py-4">
                                <span class="px-2.5 py-1 rounded-full text-[11px] font-bold border <?= $u['status'] === 'active' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-red-50 text-red-700 border-red-200' ?>">
                                    <?= ucfirst($u['status']) ?>
                                </span>
                            </td>
                            <td class="px-6 py-4">
                                <?php if ((int)$u['id'] !== (int)$admin['id']): ?>
                                    <form action="<?= APP_URL ?>/admin/users/<?= $u['id'] ?>/update-plan" method="POST" class="inline-block">
                                        <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                                        <select name="plan" onchange="this.form.submit()" class="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-black">
                                            <?php foreach ($plans as $p): ?>
                                                <option value="<?= htmlspecialchars($p['slug']) ?>" <?= ($u['plan'] ?? 'free') === $p['slug'] ? 'selected' : '' ?>>
                                                    <?= htmlspecialchars($p['name']) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </form>
                                <?php else: ?>
                                    <span class="px-2.5 py-1 rounded-full text-[11px] font-bold bg-slate-100 text-slate-500 border border-slate-200">Unlimited (SA)</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 flex items-center justify-end gap-2">
                                <?php if ((int)$u['id'] !== (int)$admin['id']): ?>
                                    <form method="POST" action="<?= APP_URL ?>/admin/users/<?= $u['id'] ?>/toggle" class="inline-block">
                                        <button type="submit" class="text-xs font-semibold px-3 py-1.5 rounded-lg border transition-colors <?= $u['status'] === 'active' ? 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100' : 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100' ?>">
                                            <?= $u['status'] === 'active' ? 'Disable' : 'Enable' ?>
                                        </button>
                                    </form>

                                    <button type="button" onclick="openChangePasswordModal(<?= $u['id'] ?>)" class="text-xs text-indigo-600 hover:text-indigo-700 font-semibold px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors border border-indigo-200/60">
                                        Password
                                    </button>

                                    <form id="delete-user-form-<?= $u['id'] ?>" method="POST" action="<?= APP_URL ?>/admin/users/<?= $u['id'] ?>/delete" class="inline-block">
                                        <button type="button" onclick="confirmDeleteUser(<?= $u['id'] ?>)" class="text-xs text-red-600 hover:text-red-700 font-semibold px-3 py-1.5 bg-red-50 hover:bg-red-100 rounded-lg transition-colors border border-red-200/60">
                                            Delete
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-xs text-slate-400 font-semibold italic">Super Admin</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination Controls -->
        <?php if ($totalPages > 1): ?>
            <div class="flex items-center justify-between border-t border-slate-100 pt-6">
                <span class="text-xs text-slate-400 font-semibold">
                    Showing Page <strong class="text-slate-700"><?= $currentPage ?></strong> of <strong class="text-slate-700"><?= $totalPages ?></strong> (Total <?= $totalUsers ?> accounts)
                </span>
                
                <div class="flex items-center gap-1.5">
                    <?php
                    $queryParams = $_GET;
                    ?>
                    <?php if ($currentPage > 1): ?>
                        <?php 
                        $queryParams['page'] = $currentPage - 1;
                        $prevUrl = APP_URL . '/admin/users?' . http_build_query($queryParams);
                        ?>
                        <a href="<?= $prevUrl ?>" class="px-3.5 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 transition-all">
                            ← Previous
                        </a>
                    <?php else: ?>
                        <button disabled class="px-3.5 py-2 bg-slate-50 border border-slate-100 rounded-xl text-xs font-bold text-slate-300 cursor-not-allowed">
                            ← Previous
                        </button>
                    <?php endif; ?>

                    <?php if ($currentPage < $totalPages): ?>
                        <?php 
                        $queryParams['page'] = $currentPage + 1;
                        $nextUrl = APP_URL . '/admin/users?' . http_build_query($queryParams);
                        ?>
                        <a href="<?= $nextUrl ?>" class="px-3.5 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 transition-all">
                            Next →
                        </a>
                    <?php else: ?>
                        <button disabled class="px-3.5 py-2 bg-slate-50 border border-slate-100 rounded-xl text-xs font-bold text-slate-300 cursor-not-allowed">
                            Next →
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Change User Password Modals -->
<?php foreach ($users as $u): ?>
    <?php if ((int)$u['id'] !== (int)$admin['id']): ?>
        <div id="change-password-modal-<?= $u['id'] ?>" class="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm hidden">
            <div class="bg-white border border-slate-200 rounded-3xl p-6 shadow-2xl max-w-sm w-full mx-4 space-y-4 text-left">
                <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                    <h3 class="font-bold text-slate-900 text-sm">Change Password for <?= htmlspecialchars($u['name']) ?></h3>
                    <button type="button" onclick="closeChangePasswordModal(<?= $u['id'] ?>)" class="text-slate-400 hover:text-slate-600 font-bold">✕</button>
                </div>
                
                <form action="<?= APP_URL ?>/admin/users/<?= $u['id'] ?>/change-password" method="POST" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                    
                    <div>
                        <label class="block text-[10px] font-bold text-slate-700 uppercase">New Password</label>
                        <input type="password" name="new_password" required placeholder="••••••••"
                               class="w-full mt-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-black">
                    </div>

                    <div>
                        <label class="block text-[10px] font-bold text-slate-700 uppercase">Confirm Password</label>
                        <input type="password" name="confirm_password" required placeholder="••••••••"
                               class="w-full mt-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-black">
                    </div>

                    <div class="pt-2 flex justify-end gap-2 border-t border-slate-100 pt-3">
                        <button type="button" onclick="closeChangePasswordModal(<?= $u['id'] ?>)" class="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all">
                            Cancel
                        </button>
                        <button type="submit" class="px-4 py-2 bg-black hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-all shadow-md">
                            Update Password
                        </button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>
<?php endforeach; ?>

<!-- SweetAlert2 Deletion Confirmation script -->
<script>
    function openChangePasswordModal(userId) {
        const modal = document.getElementById('change-password-modal-' + userId);
        if (modal) modal.classList.remove('hidden');
    }

    function closeChangePasswordModal(userId) {
        const modal = document.getElementById('change-password-modal-' + userId);
        if (modal) modal.classList.add('hidden');
    }

    function confirmDeleteUser(userId) {
        Swal.fire({
            title: 'Delete User?',
            text: "Are you sure you want to permanently delete this user account? All their data (events, bookings, settings) will be destroyed.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc2626', // Red 600
            cancelButtonColor: '#64748b',  // Slate 500
            confirmButtonText: 'Yes, delete permanently!',
            cancelButtonText: 'Cancel',
            customClass: {
                popup: 'rounded-3xl border border-slate-200 shadow-xl font-sans text-left'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('delete-user-form-' + userId).submit();
            }
        });
    }
</script>

<?php require_once TEMPLATES_DIR . '/admin/layout/footer.php'; ?>
